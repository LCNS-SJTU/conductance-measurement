#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern "C" void _CaDynamics_E2_reg(void);
extern "C" void _Ca_HVA_reg(void);
extern "C" void _Ca_LVAst_reg(void);
extern "C" void _epsp_reg(void);
extern "C" void _Ih_reg(void);
extern "C" void _Im_reg(void);
extern "C" void _K_Pst_reg(void);
extern "C" void _K_Tst_reg(void);
extern "C" void _Nap_Et2_reg(void);
extern "C" void _NaTa_t_reg(void);
extern "C" void _NaTs2_t_reg(void);
extern "C" void _SK_E2_reg(void);
extern "C" void _SKv3_1_reg(void);

extern "C" void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/CaDynamics_E2.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/Ca_HVA.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/Ca_LVAst.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/epsp.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/Ih.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/Im.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/K_Pst.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/K_Tst.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/Nap_Et2.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/NaTa_t.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/NaTs2_t.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/SK_E2.mod\"");
    fprintf(stderr, " \"/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/L5PC_neuron/L5PC/mod/SKv3_1.mod\"");
    fprintf(stderr, "\n");
  }
  _CaDynamics_E2_reg();
  _Ca_HVA_reg();
  _Ca_LVAst_reg();
  _epsp_reg();
  _Ih_reg();
  _Im_reg();
  _K_Pst_reg();
  _K_Tst_reg();
  _Nap_Et2_reg();
  _NaTa_t_reg();
  _NaTs2_t_reg();
  _SK_E2_reg();
  _SKv3_1_reg();
}
