/* Created by Language version: 7.7.0 */
/* VECTORIZED */
#define NRN_VECTORIZED 1
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mech_api.h"
#undef PI
#define nil 0
#define _pval pval
// clang-format off
#include "md1redef.h"
#include "section_fwd.hpp"
#include "nrniv_mf.h"
#include "md2redef.h"
// clang-format on
#include "neuron/cache/mechanism_range.hpp"
static constexpr auto number_of_datum_variables = 3;
static constexpr auto number_of_floating_point_variables = 19;
namespace {
template <typename T>
using _nrn_mechanism_std_vector = std::vector<T>;
using _nrn_model_sorted_token = neuron::model_sorted_token;
using _nrn_mechanism_cache_range = neuron::cache::MechanismRange<number_of_floating_point_variables, number_of_datum_variables>;
using _nrn_mechanism_cache_instance = neuron::cache::MechanismInstance<number_of_floating_point_variables, number_of_datum_variables>;
using _nrn_non_owning_id_without_container = neuron::container::non_owning_identifier_without_container;
template <typename T>
using _nrn_mechanism_field = neuron::mechanism::field<T>;
template <typename... Args>
void _nrn_mechanism_register_data_fields(Args&&... args) {
  neuron::mechanism::register_data_fields(std::forward<Args>(args)...);
}
}
 
#if !NRNGPU
#undef exp
#define exp hoc_Exp
#endif
 
#define nrn_init _nrn_init__Nafx
#define _nrn_initial _nrn_initial__Nafx
#define nrn_cur _nrn_cur__Nafx
#define _nrn_current _nrn_current__Nafx
#define nrn_jacob _nrn_jacob__Nafx
#define nrn_state _nrn_state__Nafx
#define _net_receive _net_receive__Nafx 
#define rate rate__Nafx 
#define states states__Nafx 
 
#define _threadargscomma_ _ml, _iml, _ppvar, _thread, _nt,
#define _threadargsprotocomma_ Memb_list* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, NrnThread* _nt,
#define _internalthreadargsprotocomma_ _nrn_mechanism_cache_range* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, NrnThread* _nt,
#define _threadargs_ _ml, _iml, _ppvar, _thread, _nt
#define _threadargsproto_ Memb_list* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, NrnThread* _nt
#define _internalthreadargsproto_ _nrn_mechanism_cache_range* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, NrnThread* _nt
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *hoc_getarg(int);
 
#define t _nt->_t
#define dt _nt->_dt
#define gnafbar _ml->template fpfield<0>(_iml)
#define gnafbar_columnindex 0
#define ar2 _ml->template fpfield<1>(_iml)
#define ar2_columnindex 1
#define ina _ml->template fpfield<2>(_iml)
#define ina_columnindex 2
#define gna _ml->template fpfield<3>(_iml)
#define gna_columnindex 3
#define m _ml->template fpfield<4>(_iml)
#define m_columnindex 4
#define h _ml->template fpfield<5>(_iml)
#define h_columnindex 5
#define s _ml->template fpfield<6>(_iml)
#define s_columnindex 6
#define ena _ml->template fpfield<7>(_iml)
#define ena_columnindex 7
#define Dm _ml->template fpfield<8>(_iml)
#define Dm_columnindex 8
#define Dh _ml->template fpfield<9>(_iml)
#define Dh_columnindex 9
#define Ds _ml->template fpfield<10>(_iml)
#define Ds_columnindex 10
#define minf _ml->template fpfield<11>(_iml)
#define minf_columnindex 11
#define hinf _ml->template fpfield<12>(_iml)
#define hinf_columnindex 12
#define sinf _ml->template fpfield<13>(_iml)
#define sinf_columnindex 13
#define mtau _ml->template fpfield<14>(_iml)
#define mtau_columnindex 14
#define htau _ml->template fpfield<15>(_iml)
#define htau_columnindex 15
#define stau _ml->template fpfield<16>(_iml)
#define stau_columnindex 16
#define v _ml->template fpfield<17>(_iml)
#define v_columnindex 17
#define _g _ml->template fpfield<18>(_iml)
#define _g_columnindex 18
#define _ion_ena *(_ml->dptr_field<0>(_iml))
#define _p_ion_ena static_cast<neuron::container::data_handle<double>>(_ppvar[0])
#define _ion_ina *(_ml->dptr_field<1>(_iml))
#define _p_ion_ina static_cast<neuron::container::data_handle<double>>(_ppvar[1])
#define _ion_dinadv *(_ml->dptr_field<2>(_iml))
 /* Thread safe. No static _ml, _iml or _ppvar. */
 static int hoc_nrnpointerindex =  -1;
 static _nrn_mechanism_std_vector<Datum> _extcall_thread;
 static Prop* _extcall_prop;
 /* _prop_id kind of shadows _extcall_prop to allow validity checking. */
 static _nrn_non_owning_id_without_container _prop_id{};
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static void _hoc_alpr(void);
 static void _hoc_alpv(void);
 static void _hoc_betr(void);
 static void _hoc_hbet(void);
 static void _hoc_half(void);
 static void _hoc_mbet(void);
 static void _hoc_malf(void);
 static void _hoc_rate(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
 
#define NMODL_TEXT 1
#if NMODL_TEXT
static void register_nmodl_text_and_filename(int mechtype);
#endif
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _extcall_prop = _prop;
 _prop_id = _nrn_get_prop_id(_prop);
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 {"setdata_Nafx", _hoc_setdata},
 {"alpr_Nafx", _hoc_alpr},
 {"alpv_Nafx", _hoc_alpv},
 {"betr_Nafx", _hoc_betr},
 {"hbet_Nafx", _hoc_hbet},
 {"half_Nafx", _hoc_half},
 {"mbet_Nafx", _hoc_mbet},
 {"malf_Nafx", _hoc_malf},
 {"rate_Nafx", _hoc_rate},
 {0, 0}
};
 
/* Direct Python call wrappers to density mechanism functions.*/
 static double _npy_alpr(Prop*);
 static double _npy_alpv(Prop*);
 static double _npy_betr(Prop*);
 static double _npy_hbet(Prop*);
 static double _npy_half(Prop*);
 static double _npy_mbet(Prop*);
 static double _npy_malf(Prop*);
 static double _npy_rate(Prop*);
 
static NPyDirectMechFunc npy_direct_func_proc[] = {
 {"alpr", _npy_alpr},
 {"alpv", _npy_alpv},
 {"betr", _npy_betr},
 {"hbet", _npy_hbet},
 {"half", _npy_half},
 {"mbet", _npy_mbet},
 {"malf", _npy_malf},
 {"rate", _npy_rate},
 {0, 0}
};
#define alpr alpr_Nafx
#define alpv alpv_Nafx
#define betr betr_Nafx
#define hbet hbet_Nafx
#define half half_Nafx
#define mbet mbet_Nafx
#define malf malf_Nafx
 extern double alpr( _internalthreadargsprotocomma_ double );
 extern double alpv( _internalthreadargsprotocomma_ double );
 extern double betr( _internalthreadargsprotocomma_ double );
 extern double hbet( _internalthreadargsprotocomma_ double );
 extern double half( _internalthreadargsprotocomma_ double );
 extern double mbet( _internalthreadargsprotocomma_ double );
 extern double malf( _internalthreadargsprotocomma_ double );
 /* declare global and static user variables */
#define a0r a0r_Nafx
 double a0r = 0.0003;
#define b0r b0r_Nafx
 double b0r = 0.0003;
#define gmr gmr_Nafx
 double gmr = 0.2;
#define taumin taumin_Nafx
 double taumin = 30;
#define vvs vvs_Nafx
 double vvs = 2;
#define vvh vvh_Nafx
 double vvh = -58;
#define vhalfr vhalfr_Nafx
 double vhalfr = -60;
#define zetas zetas_Nafx
 double zetas = 12;
#define zetar zetar_Nafx
 double zetar = 12;
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 {0, 0, 0}
};
 static HocParmUnits _hoc_parm_units[] = {
 {"taumin_Nafx", "ms"},
 {"vhalfr_Nafx", "mV"},
 {"vvh_Nafx", "mV"},
 {"vvs_Nafx", "mV"},
 {"a0r_Nafx", "/ms"},
 {"b0r_Nafx", "/ms"},
 {"gnafbar_Nafx", "mho/cm2"},
 {"ina_Nafx", "mA/cm2"},
 {"gna_Nafx", "mho/cm2"},
 {0, 0}
};
 static double delta_t = 0.01;
 static double h0 = 0;
 static double m0 = 0;
 static double s0 = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 {"taumin_Nafx", &taumin_Nafx},
 {"vhalfr_Nafx", &vhalfr_Nafx},
 {"vvh_Nafx", &vvh_Nafx},
 {"vvs_Nafx", &vvs_Nafx},
 {"a0r_Nafx", &a0r_Nafx},
 {"b0r_Nafx", &b0r_Nafx},
 {"zetar_Nafx", &zetar_Nafx},
 {"zetas_Nafx", &zetas_Nafx},
 {"gmr_Nafx", &gmr_Nafx},
 {0, 0}
};
 static DoubVec hoc_vdoub[] = {
 {0, 0, 0}
};
 static double _sav_indep;
 static void nrn_alloc(Prop*);
static void nrn_init(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void nrn_state(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 static void nrn_cur(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void nrn_jacob(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(Prop*, int, neuron::container::data_handle<double>*, neuron::container::data_handle<double>*, double*, int);
static void _ode_spec(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void _ode_matsol(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 
#define _cvode_ieq _ppvar[3].literal_value<int>()
 static void _ode_matsol_instance1(_internalthreadargsproto_);
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "7.7.0",
"Nafx",
 "gnafbar_Nafx",
 "ar2_Nafx",
 0,
 "ina_Nafx",
 "gna_Nafx",
 0,
 "m_Nafx",
 "h_Nafx",
 "s_Nafx",
 0,
 0};
 static Symbol* _na_sym;
 
 /* Used by NrnProperty */
 static _nrn_mechanism_std_vector<double> _parm_default{
     0, /* gnafbar */
     1, /* ar2 */
 }; 
 
 
extern Prop* need_memb(Symbol*);
static void nrn_alloc(Prop* _prop) {
  Prop *prop_ion{};
  Datum *_ppvar{};
   _ppvar = nrn_prop_datum_alloc(_mechtype, 4, _prop);
    _nrn_mechanism_access_dparam(_prop) = _ppvar;
     _nrn_mechanism_cache_instance _ml_real{_prop};
    auto* const _ml = &_ml_real;
    size_t const _iml{};
    assert(_nrn_mechanism_get_num_vars(_prop) == 19);
 	/*initialize range parameters*/
 	gnafbar = _parm_default[0]; /* 0 */
 	ar2 = _parm_default[1]; /* 1 */
 	 assert(_nrn_mechanism_get_num_vars(_prop) == 19);
 	_nrn_mechanism_access_dparam(_prop) = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_na_sym);
 nrn_promote(prop_ion, 0, 1);
 	_ppvar[0] = _nrn_mechanism_get_param_handle(prop_ion, 0); /* ena */
 	_ppvar[1] = _nrn_mechanism_get_param_handle(prop_ion, 3); /* ina */
 	_ppvar[2] = _nrn_mechanism_get_param_handle(prop_ion, 4); /* _ion_dinadv */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 {0, 0}
};
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*)(Datum*));
void _nrn_thread_table_reg(int, nrn_thread_table_check_t);
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 extern "C" void _nafx_reg() {
	int _vectorized = 1;
  _initlists();
 	ion_reg("na", -10000.);
 	_na_sym = hoc_lookup("na_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 1);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
 hoc_register_parm_default(_mechtype, &_parm_default);
         hoc_register_npy_direct(_mechtype, npy_direct_func_proc);
     _nrn_setdata_reg(_mechtype, _setdata);
 #if NMODL_TEXT
  register_nmodl_text_and_filename(_mechtype);
#endif
   _nrn_mechanism_register_data_fields(_mechtype,
                                       _nrn_mechanism_field<double>{"gnafbar"} /* 0 */,
                                       _nrn_mechanism_field<double>{"ar2"} /* 1 */,
                                       _nrn_mechanism_field<double>{"ina"} /* 2 */,
                                       _nrn_mechanism_field<double>{"gna"} /* 3 */,
                                       _nrn_mechanism_field<double>{"m"} /* 4 */,
                                       _nrn_mechanism_field<double>{"h"} /* 5 */,
                                       _nrn_mechanism_field<double>{"s"} /* 6 */,
                                       _nrn_mechanism_field<double>{"ena"} /* 7 */,
                                       _nrn_mechanism_field<double>{"Dm"} /* 8 */,
                                       _nrn_mechanism_field<double>{"Dh"} /* 9 */,
                                       _nrn_mechanism_field<double>{"Ds"} /* 10 */,
                                       _nrn_mechanism_field<double>{"minf"} /* 11 */,
                                       _nrn_mechanism_field<double>{"hinf"} /* 12 */,
                                       _nrn_mechanism_field<double>{"sinf"} /* 13 */,
                                       _nrn_mechanism_field<double>{"mtau"} /* 14 */,
                                       _nrn_mechanism_field<double>{"htau"} /* 15 */,
                                       _nrn_mechanism_field<double>{"stau"} /* 16 */,
                                       _nrn_mechanism_field<double>{"v"} /* 17 */,
                                       _nrn_mechanism_field<double>{"_g"} /* 18 */,
                                       _nrn_mechanism_field<double*>{"_ion_ena", "na_ion"} /* 0 */,
                                       _nrn_mechanism_field<double*>{"_ion_ina", "na_ion"} /* 1 */,
                                       _nrn_mechanism_field<double*>{"_ion_dinadv", "na_ion"} /* 2 */,
                                       _nrn_mechanism_field<int>{"_cvode_ieq", "cvodeieq"} /* 3 */);
  hoc_register_prop_size(_mechtype, 19, 4);
  hoc_register_dparam_semantics(_mechtype, 0, "na_ion");
  hoc_register_dparam_semantics(_mechtype, 1, "na_ion");
  hoc_register_dparam_semantics(_mechtype, 2, "na_ion");
  hoc_register_dparam_semantics(_mechtype, 3, "cvodeieq");
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 
    hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 Nafx /home/wzl/LFPy/project/conductance_measurement/realistic_neuron/FS/TzilivakiEtal_FSBCs_model/Multicompartmental_Biophysical_models/mechanism/nafx.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
static int _reset;
static const char *modelname = "";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int rate(_internalthreadargsprotocomma_ double, double);
 
static int _ode_spec1(_internalthreadargsproto_);
/*static int _ode_matsol1(_internalthreadargsproto_);*/
 static neuron::container::field_index _slist1[3], _dlist1[3];
 static int states(_internalthreadargsproto_);
 
/*CVODE*/
 static int _ode_spec1 (_internalthreadargsproto_) {int _reset = 0; {
   rate ( _threadargscomma_ v , ar2 ) ;
   Dm = ( minf - m ) / mtau ;
   Dh = ( hinf - h ) / htau ;
   Ds = ( sinf - s ) / stau ;
   }
 return _reset;
}
 static int _ode_matsol1 (_internalthreadargsproto_) {
 rate ( _threadargscomma_ v , ar2 ) ;
 Dm = Dm  / (1. - dt*( ( ( ( - 1.0 ) ) ) / mtau )) ;
 Dh = Dh  / (1. - dt*( ( ( ( - 1.0 ) ) ) / htau )) ;
 Ds = Ds  / (1. - dt*( ( ( ( - 1.0 ) ) ) / stau )) ;
  return 0;
}
 /*END CVODE*/
 static int states (_internalthreadargsproto_) { {
   rate ( _threadargscomma_ v , ar2 ) ;
    m = m + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / mtau)))*(- ( ( ( minf ) ) / mtau ) / ( ( ( ( - 1.0 ) ) ) / mtau ) - m) ;
    h = h + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / htau)))*(- ( ( ( hinf ) ) / htau ) / ( ( ( ( - 1.0 ) ) ) / htau ) - h) ;
    s = s + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / stau)))*(- ( ( ( sinf ) ) / stau ) / ( ( ( ( - 1.0 ) ) ) / stau ) - s) ;
   }
  return 0;
}
 
double malf ( _internalthreadargsprotocomma_ double _lv ) {
   double _lmalf;
 double _lva ;
 _lva = _lv + 28.0 ;
   if ( fabs ( _lva ) < 1e-04 ) {
     _lmalf = - 0.2816 * ( - 9.3 + _lva * 0.5 ) ;
     }
   else {
     _lmalf = - 0.2816 * ( _lv + 28.0 ) / ( - 1.0 + exp ( - _lva / 9.3 ) ) ;
     }
   
return _lmalf;
 }
 
static void _hoc_malf(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  malf ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_malf(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  malf ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
double mbet ( _internalthreadargsprotocomma_ double _lv ) {
   double _lmbet;
 double _lvb ;
 _lvb = _lv + 1.0 ;
   if ( fabs ( _lvb ) < 1e-04 ) {
     _lmbet = 0.2464 * ( 6.0 + _lvb * 0.5 ) ;
     }
   else {
     _lmbet = 0.2464 * ( _lv + 1.0 ) / ( - 1.0 + exp ( _lvb / 6.0 ) ) ;
     }
   
return _lmbet;
 }
 
static void _hoc_mbet(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  mbet ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_mbet(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  mbet ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
double half ( _internalthreadargsprotocomma_ double _lv ) {
   double _lhalf;
 double _lvc ;
 _lvc = _lv + 40.1 ;
   if ( fabs ( _lvc ) < 1e-04 ) {
     _lhalf = 0.098 * ( 20.0 + _lvc * 0.5 ) ;
     }
   else {
     _lhalf = 0.098 / exp ( _lvc + 43.1 / 20.0 ) ;
     }
   
return _lhalf;
 }
 
static void _hoc_half(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  half ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_half(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  half ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
double hbet ( _internalthreadargsprotocomma_ double _lv ) {
   double _lhbet;
 double _lvd ;
 _lvd = _lv + 13.1 ;
   if ( fabs ( _lvd ) < 1e-04 ) {
     _lhbet = 1.4 * ( 10.0 + _lvd * 0.5 ) ;
     }
   else {
     _lhbet = 1.4 / ( 1.0 + exp ( - ( _lvd - 13.1 ) / 10.0 ) ) ;
     }
   
return _lhbet;
 }
 
static void _hoc_hbet(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  hbet ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_hbet(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  hbet ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
double alpv ( _internalthreadargsprotocomma_ double _lv ) {
   double _lalpv;
 _lalpv = 1.0 / ( 1.0 + exp ( ( _lv - vvh ) / vvs ) ) ;
   
return _lalpv;
 }
 
static void _hoc_alpv(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  alpv ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_alpv(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  alpv ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
double alpr ( _internalthreadargsprotocomma_ double _lv ) {
   double _lalpr;
 _lalpr = exp ( 1.e-3 * zetar * ( _lv - vhalfr ) * 9.648e4 / ( 8.315 * ( 273.16 + celsius ) ) ) ;
   
return _lalpr;
 }
 
static void _hoc_alpr(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  alpr ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_alpr(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  alpr ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
double betr ( _internalthreadargsprotocomma_ double _lv ) {
   double _lbetr;
 _lbetr = exp ( 1.e-3 * zetar * gmr * ( _lv - vhalfr ) * 9.648e4 / ( 8.315 * ( 273.16 + celsius ) ) ) ;
   
return _lbetr;
 }
 
static void _hoc_betr(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  betr ( _threadargscomma_ *getarg(1) );
 hoc_retpushx(_r);
}
 
static double _npy_betr(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r =  betr ( _threadargscomma_ *getarg(1) );
 return(_r);
}
 
static int  rate ( _internalthreadargsprotocomma_ double _lv , double _lar2 ) {
   double _lq10 , _lmsum , _lhsum , _lma , _lmb , _lha , _lhb , _lc ;
 _lma = malf ( _threadargscomma_ _lv ) ;
   _lmb = mbet ( _threadargscomma_ _lv ) ;
   _lha = half ( _threadargscomma_ _lv ) ;
   _lhb = hbet ( _threadargscomma_ _lv ) ;
   _lmsum = _lma + _lmb ;
   minf = _lma / _lmsum ;
   mtau = 1.0 / ( _lmsum ) ;
   _lhsum = _lha + _lhb ;
   hinf = _lha / _lhsum ;
   htau = 1.0 / ( _lhsum ) ;
   stau = betr ( _threadargscomma_ _lv ) / ( a0r * ( 1.0 + alpr ( _threadargscomma_ _lv ) ) ) ;
   if ( stau < taumin ) {
     stau = taumin ;
     }
   _lc = alpv ( _threadargscomma_ _lv ) ;
   sinf = _lc + _lar2 * ( 1.0 - _lc ) ;
    return 0; }
 
static void _hoc_rate(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  Prop* _local_prop = _prop_id ? _extcall_prop : nullptr;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r = 1.;
 rate ( _threadargscomma_ *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
static double _npy_rate(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
_nt = nrn_threads;
 _r = 1.;
 rate ( _threadargscomma_ *getarg(1) , *getarg(2) );
 return(_r);
}
 
static int _ode_count(int _type){ return 3;}
 
static void _ode_spec(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
   Datum* _ppvar;
   size_t _iml;   _nrn_mechanism_cache_range* _ml;   Node* _nd{};
  double _v{};
  int _cntml;
  _nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
  _ml = &_lmr;
  _cntml = _ml_arg->_nodecount;
  Datum *_thread{_ml_arg->_thread};
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _ppvar = _ml_arg->_pdata[_iml];
    _nd = _ml_arg->_nodelist[_iml];
    v = NODEV(_nd);
  ena = _ion_ena;
     _ode_spec1 (_threadargs_);
  }}
 
static void _ode_map(Prop* _prop, int _ieq, neuron::container::data_handle<double>* _pv, neuron::container::data_handle<double>* _pvdot, double* _atol, int _type) { 
  Datum* _ppvar;
  _ppvar = _nrn_mechanism_access_dparam(_prop);
  _cvode_ieq = _ieq;
  for (int _i=0; _i < 3; ++_i) {
    _pv[_i] = _nrn_mechanism_get_param_handle(_prop, _slist1[_i]);
    _pvdot[_i] = _nrn_mechanism_get_param_handle(_prop, _dlist1[_i]);
    _cvode_abstol(_atollist, _atol, _i);
  }
 }
 
static void _ode_matsol_instance1(_internalthreadargsproto_) {
 _ode_matsol1 (_threadargs_);
 }
 
static void _ode_matsol(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
   Datum* _ppvar;
   size_t _iml;   _nrn_mechanism_cache_range* _ml;   Node* _nd{};
  double _v{};
  int _cntml;
  _nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
  _ml = &_lmr;
  _cntml = _ml_arg->_nodecount;
  Datum *_thread{_ml_arg->_thread};
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _ppvar = _ml_arg->_pdata[_iml];
    _nd = _ml_arg->_nodelist[_iml];
    v = NODEV(_nd);
  ena = _ion_ena;
 _ode_matsol_instance1(_threadargs_);
 }}

static void initmodel(_internalthreadargsproto_) {
  int _i; double _save;{
  h = h0;
  m = m0;
  s = s0;
 {
   rate ( _threadargscomma_ v , ar2 ) ;
   m = minf ;
   h = hinf ;
   s = sinf ;
   }
 
}
}

static void nrn_init(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type){
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto* const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
   _v = _vec_v[_ni[_iml]];
 v = _v;
  ena = _ion_ena;
 initmodel(_threadargs_);
 }
}

static double _nrn_current(_internalthreadargsprotocomma_ double _v) {
double _current=0.; v=_v;
{ {
   gna = gnafbar * m * m * m * h * s ;
   ina = gna * ( v - 55.0 ) ;
   }
 _current += ina;

} return _current;
}

static void nrn_cur(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto const _vec_rhs = _nt->node_rhs_storage();
auto const _vec_sav_rhs = _nt->node_sav_rhs_storage();
auto const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
   _v = _vec_v[_ni[_iml]];
  ena = _ion_ena;
 auto const _g_local = _nrn_current(_threadargscomma_ _v + .001);
 	{ double _dina;
  _dina = ina;
 _rhs = _nrn_current(_threadargscomma_ _v);
  _ion_dinadv += (_dina - ina)/.001 ;
 	}
 _g = (_g_local - _rhs)/.001;
  _ion_ina += ina ;
	 _vec_rhs[_ni[_iml]] -= _rhs;
 
}
 
}

static void nrn_jacob(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto const _vec_d = _nt->node_d_storage();
auto const _vec_sav_d = _nt->node_sav_d_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
  _vec_d[_ni[_iml]] += _g;
 
}
 
}

static void nrn_state(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto* const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; double _v = 0.0; int* _ni;
_ni = _ml_arg->_nodeindices;
size_t _cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
for (size_t _iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
 _nd = _ml_arg->_nodelist[_iml];
   _v = _vec_v[_ni[_iml]];
 v=_v;
{
  ena = _ion_ena;
 {   states(_threadargs_);
  } }}

}

static void terminal(){}

static void _initlists(){
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = {m_columnindex, 0};  _dlist1[0] = {Dm_columnindex, 0};
 _slist1[1] = {h_columnindex, 0};  _dlist1[1] = {Dh_columnindex, 0};
 _slist1[2] = {s_columnindex, 0};  _dlist1[2] = {Ds_columnindex, 0};
_first = 0;
}

#if NMODL_TEXT
static void register_nmodl_text_and_filename(int mech_type) {
    const char* nmodl_filename = "/home/wzl/LFPy/project/conductance_measurement/realistic_neuron/FS/TzilivakiEtal_FSBCs_model/Multicompartmental_Biophysical_models/mechanism/nafx.mod";
    const char* nmodl_file_text = 
  ": Fast Na+ channel\n"
  ": added the 's' attenuation system from hha2.mod\n"
  ": Kiki Sidiropoulou\n"
  ": September 27, 2007\n"
  "\n"
  "NEURON {\n"
  "	SUFFIX Nafx\n"
  "	USEION na READ ena WRITE ina\n"
  "	RANGE gnafbar, ina, gna, ar2\n"
  "}\n"
  "\n"
  "UNITS {\n"
  "	(mA) = (milliamp)\n"
  "	(mV) = (millivolt)\n"
  "	\n"
  "}\n"
  "\n"
  "INDEPENDENT {t FROM 0 TO 1 WITH 1 (ms)}\n"
  "\n"
  "PARAMETER {\n"
  "	v (mV)\n"
  "	dt (ms)\n"
  "	gnafbar	= 0 (mho/cm2)\n"
  "	:gnafbar= 0.086 (mho/cm2) <0,1e9>\n"
  "	ena = 55 (mV)\n"
  "	\n"
  "	:PARAMETERS FOR S ATTENUATION SYSTEM\n"
  "	taumin = 30 (ms)  :min activation time for \"s\" attenuation system\n"
  "        vhalfr =-60 (mV)       :half potential for \"s\" attenuation system, -60\n"
  "        vvh=-58		(mV) \n"
  " 	vvs = 2 (mV)\n"
  "	a0r = 0.0003 (/ms)\n"
  "        b0r = 0.0003 (/ms)\n"
  "       : a0r = 0.0003 (ms)\n"
  "        :b0r = 0.0003 (ms)\n"
  "        zetar = 12    \n"
  "	zetas = 12   \n"
  "        gmr = 0.2   \n"
  "	ar2 = 1.0               :initialized parameter for location-dependent\n"
  "                                :Na-conductance attenuation, \"s\", (ar=1 -> zero attenuation)\n"
  "}\n"
  "STATE {\n"
  "	m h s\n"
  "}\n"
  "ASSIGNED {\n"
  "	celsius (degC)\n"
  "	ina (mA/cm2)\n"
  "	minf \n"
  "	hinf\n"
  "	sinf \n"
  "	mtau (ms)\n"
  "	htau (ms)\n"
  "	stau (ms)\n"
  "	gna (mho/cm2)\n"
  "	\n"
  "}\n"
  "\n"
  "\n"
  "\n"
  "INITIAL {\n"
  "	rate(v, ar2)\n"
  "	m = minf\n"
  "	h = hinf\n"
  "	s = sinf\n"
  "}\n"
  "\n"
  "BREAKPOINT {\n"
  "	SOLVE states METHOD cnexp\n"
  "	gna = gnafbar*m*m*m*h*s\n"
  "	ina = gna*(v-55)\n"
  "	\n"
  "}\n"
  "\n"
  "DERIVATIVE states {\n"
  "	rate(v, ar2)\n"
  "	m' = (minf-m)/mtau\n"
  "	h' = (hinf-h)/htau\n"
  "	s' = (sinf-s)/stau\n"
  "}\n"
  "\n"
  "UNITSOFF\n"
  "\n"
  "FUNCTION malf( v){ LOCAL va \n"
  "	va=v+28\n"
  "	:va=v+28\n"
  "	if (fabs(va)<1e-04){\n"
  "	   malf= -0.2816*(-9.3 + va*0.5)\n"
  "	   :malf= -0.2816*(-9.3 + va*0.5)\n"
  "	}else{\n"
  "	   malf = -0.2816*(v+28)/(-1+exp(-va/9.3))\n"
  "	}\n"
  "}\n"
  "\n"
  "\n"
  "FUNCTION mbet(v(mV))(/ms) { LOCAL vb \n"
  "	vb=v+1\n"
  "	:vb=v+1\n"
  "	if (fabs(vb)<1e-04){\n"
  "	    mbet = 0.2464*(6+vb*0.5)\n"
  "	    :mbet = 0.2464*(6 + vb*0.5)\n"
  "	}else{\n"
  "	   mbet = 0.2464*(v+1)/(-1+exp(vb/6))	  :/(-1+exp((v+1)/6))\n"
  "	}\n"
  "	}	\n"
  "\n"
  "\n"
  "FUNCTION half(v(mV))(/ms) { LOCAL vc \n"
  "	:vc=v+15.1\n"
  "	vc=v+40.1	:changed to 40.1 by kiki\n"
  "	if (fabs(vc)<1e-04){\n"
  "	   half=0.098*(20 + vc*0.5)\n"
  "	}else{\n"
  "	   half=0.098/exp(vc+43.1/20)  :43.1, also spike train attenuation\n"
  "}\n"
  "}\n"
  "\n"
  "\n"
  "FUNCTION hbet(v(mV))(/ms) { LOCAL vd\n"
  "	:vd=v+13.1\n"
  "	vd=v+13.1  :decreasing it increases the peak current\n"
  "	if (fabs(vd)<1e-04){\n"
  "	   hbet=1.4*(10 + vd*0.5)\n"
  "	}else{\n"
  "	   hbet=1.4/(1+exp(-(vd-13.1)/10))  :13.1 increasing it, increases the spike train attenuation and increases spike width\n"
  "} \n"
  "}\n"
  "\n"
  "\n"
  ":FUNCTIONS FOR S \n"
  "FUNCTION alpv(v(mV)) {\n"
  "         alpv = 1/(1+exp((v-vvh)/vvs))\n"
  "}\n"
  "\n"
  "\n"
  "FUNCTION alpr(v(mV)) {       :used in \"s\" activation system tau\n"
  "\n"
  "  alpr = exp(1.e-3*zetar*(v-vhalfr)*9.648e4/(8.315*(273.16+celsius))) \n"
  "}\n"
  "\n"
  "FUNCTION betr(v(mV)) {       :used in \"s\" activation system tau\n"
  "\n"
  "  betr = exp(1.e-3*zetar*gmr*(v-vhalfr)*9.648e4/(8.315*(273.16+celsius))) \n"
  "}\n"
  "\n"
  "\n"
  "\n"
  "PROCEDURE rate(v (mV),ar2) {LOCAL q10, msum, hsum, ma, mb, ha, hb,c\n"
  "	\n"
  "\n"
  "	ma=malf(v) mb=mbet(v) ha=half(v) hb=hbet(v)\n"
  "	\n"
  "	msum = ma+mb\n"
  "	minf = ma/msum\n"
  "	mtau = 1/(msum)\n"
  "	\n"
  "	\n"
  "	hsum=ha+hb\n"
  "	hinf=ha/hsum\n"
  "	htau = 1 / (hsum)\n"
  "\n"
  "	stau = betr(v)/(a0r*(1+alpr(v))) \n"
  "	if (stau<taumin) {stau=taumin} :s activation tau\n"
  "	c = alpv(v)\n"
  "	sinf = c+ar2*(1-c) 	\n"
  "}\n"
  "\n"
  "	\n"
  "UNITSON\n"
  "\n"
  "\n"
  ;
    hoc_reg_nmodl_filename(mech_type, nmodl_filename);
    hoc_reg_nmodl_text(mech_type, nmodl_file_text);
}
#endif
